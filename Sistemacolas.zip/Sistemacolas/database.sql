-- -----------------------------------------------------
-- Script: esquema y datos iniciales (minúsculas)
-- -----------------------------------------------------

-- ROLES
CREATE TABLE IF NOT EXISTS roles (
  idrol SERIAL PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL UNIQUE
);

-- USUARIOS
CREATE TABLE IF NOT EXISTS usuarios (
  idusuario SERIAL PRIMARY KEY,
  nombrecompleto VARCHAR(120) NOT NULL,
  usuario VARCHAR(60) NOT NULL UNIQUE,
  correo VARCHAR(120),
  contrasenahash VARCHAR(300) NOT NULL,
  idrol INT NOT NULL,
  activo BOOLEAN DEFAULT TRUE,
  fechacreacion TIMESTAMP DEFAULT NOW(),
  CONSTRAINT fk_usuarios_roles FOREIGN KEY (idrol) REFERENCES roles(idrol)
);

-- PACIENTES
CREATE TABLE IF NOT EXISTS pacientes (
  idpaciente SERIAL PRIMARY KEY,
  dpi VARCHAR(30) UNIQUE,
  nombrecompleto VARCHAR(120) NOT NULL,
  fechanacimiento DATE,
  telefono VARCHAR(20),
  direccion VARCHAR(200),
  correo VARCHAR(120),
  fecharegistro TIMESTAMP DEFAULT NOW()
);

-- AREAS HOSPITALARIAS
CREATE TABLE IF NOT EXISTS areashospital (
  idarea SERIAL PRIMARY KEY,
  nombrearea VARCHAR(80) NOT NULL UNIQUE,
  descripcion VARCHAR(200),
  activo BOOLEAN DEFAULT TRUE
);

-- ESTADO DEL TURNO
CREATE TABLE IF NOT EXISTS estadoturno (
  idestado SERIAL PRIMARY KEY,
  estado VARCHAR(40) NOT NULL UNIQUE
);

-- TURNOS
CREATE TABLE IF NOT EXISTS turnos (
  idturno SERIAL PRIMARY KEY,
  numeroturno INT NOT NULL,
  idpaciente INT NOT NULL,
  idarea INT NOT NULL,
  idestado INT NOT NULL DEFAULT 1,
  priorizacion VARCHAR(20) DEFAULT 'Normal',
  fechacreacion TIMESTAMP DEFAULT NOW(),
  llamadoen TIMESTAMP NULL,
  atendidoen TIMESTAMP NULL,
  finalizadoen TIMESTAMP NULL,
  CONSTRAINT fk_turnos_paciente FOREIGN KEY (idpaciente) REFERENCES pacientes(idpaciente),
  CONSTRAINT fk_turnos_area FOREIGN KEY (idarea) REFERENCES areashospital(idarea),
  CONSTRAINT fk_turnos_estado FOREIGN KEY (idestado) REFERENCES estadoturno(idestado)
);

-- HISTORIAL DE ATENCION
CREATE TABLE IF NOT EXISTS historialatencion (
  idhistorial SERIAL PRIMARY KEY,
  idturno INT NOT NULL,
  idusuario INT NOT NULL,
  observaciones VARCHAR(500),
  fechaatencion TIMESTAMP DEFAULT NOW(),
  CONSTRAINT fk_historial_turno FOREIGN KEY (idturno) REFERENCES turnos(idturno),
  CONSTRAINT fk_historial_usuario FOREIGN KEY (idusuario) REFERENCES usuarios(idusuario)
);

-- DISPLAY
CREATE TABLE IF NOT EXISTS display (
  iddisplay SERIAL PRIMARY KEY,
  idarea INT NOT NULL,
  turnoactual INT NULL,
  turnosiguiente INT NULL,
  ultimaactualizacion TIMESTAMP DEFAULT NOW(),
  CONSTRAINT fk_display_area FOREIGN KEY (idarea) REFERENCES areashospital(idarea)
);

-- AUDITORIA
CREATE TABLE IF NOT EXISTS auditoria (
  idauditoria SERIAL PRIMARY KEY,
  tabla VARCHAR(50),
  operacion VARCHAR(20),
  usuario VARCHAR(100),
  fecha TIMESTAMP DEFAULT NOW(),
  datosanterior TEXT,
  datosdespues TEXT
);

-- INSERTS INICIALES
-- Roles
INSERT INTO roles (nombre)
SELECT val FROM (VALUES('admin'),('medico'),('enfermero'),('recepcion')) AS t(val)
ON CONFLICT (nombre) DO NOTHING;

-- Estados del turno
INSERT INTO estadoturno (estado)
SELECT val FROM (VALUES('Espera'),('Llamando'),('Atendiendo'),('Finalizado'),('Ausente')) AS t(val)
ON CONFLICT (estado) DO NOTHING;

-- Areas hospitalarias
INSERT INTO areashospital (nombrearea, descripcion)
SELECT v.nombrearea, v.descripcion FROM (VALUES
  ('Emergencias','Atención inmediata'),
  ('Pediatría','Atención infantil'),
  ('Ginecología','Salud femenina'),
  ('Medicina General','Consultas generales'),
  ('Traumatología','Fracturas y lesiones físicas')
) AS v(nombrearea, descripcion)
ON CONFLICT (nombrearea) DO NOTHING;

-- USUARIO ADMIN (si no existe)
-- Nota: el contrasenahash está en bcrypt y corresponde al hash que tenías en tu script original.
INSERT INTO usuarios (nombrecompleto, usuario, correo, contrasenahash, idrol)
SELECT 'Administrador General','admin','admin@sistemacolas.com',
  '$2a$10$gLFuD2cwr6jciJ6TP2PumoK4DYZ5Q2wMP3xPHYG.G3gPNQ0xPA2iW', 1
WHERE NOT EXISTS (SELECT 1 FROM usuarios WHERE usuario = 'admin');
